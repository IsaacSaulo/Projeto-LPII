

class Carro:

    def __init__(self, db):
        self.placa = db.Column(db.String(8), primary_key=True, autoincrement=True)
        self.marca = db.Column(db.String(50), nullable=False)
        self.modelo = db.Column(db.String(50), nullable=False)
        self.ano = db.Column(db.Integer, nullable=False)
        self.cor = db.Column(db.String(50), nullable=False)
        self.preco = db.Column(db.Float, nullable=False)
        self.status = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"Carro('{self.placa}', '{self.marca}', '{self.modelo}', '{self.ano}', '{self.cor}', '{self.preco}')"
