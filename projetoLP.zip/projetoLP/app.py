from datetime import datetime, date
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'ifsp_lp2'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banco.db'

db = SQLAlchemy(app)


class Cliente(db.Model):
    cpf = db.Column(db.String(11), primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    telefone = db.Column(db.String(11), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    endereco = db.Column(db.String(100), nullable=False)
    cidade = db.Column(db.String(100), nullable=False)
    numero = db.Column(db.String(100), nullable=False)
    cep = db.Column(db.String(100), nullable=False)
    bairro = db.Column(db.String(100), nullable=False)
    data_nascimento = db.Column(db.Date, nullable=False)

    def locar(self):
        pass

    def devolver(self):
        pass

    def __repr__(self):
        return f"Cliente('{self.cpf}', '{self.nome}', '{self.telefone}', '{self.email}', '{self.endereco}', " \
               f"'{self.cidade}', '{self.numero}', '{self.cep}', '{self.bairro}', '{self.data_nascimento}')"


class Carro(db.Model):

    placa = db.Column(db.String(8), primary_key=True)
    marca = db.Column(db.String(50), nullable=False)
    descricao = db.Column(db.String(280), nullable=False)
    modelo = db.Column(db.String(100), nullable=False)
    cor = db.Column(db.String(50), nullable=False)
    valor = db.Column(db.Float, nullable=False)
    status = db.Column(db.Integer, nullable=False)
    imagem = db.Column(db.String(280), nullable=False)

    def __repr__(self):
        return f"Carro('{self.placa}', '{self.marca}', '{self.descricao}', '{self.modelo}', '{self.cor}', " \
                f"'{self.valor}', '{self.status}', '{self.imagem}')"


@app.route('/')
def index():
    return render_template("index.html", pagina='Dashboard', aba_ativa='dashboard')


@app.route('/carros')
def carros():
    carros = Carro.query.all()
    return render_template("carros.html", pagina='Carros', aba_ativa='cars', lista_carros=carros)


@app.route('/garagem')
def garagem():
    return render_template("garagem.html", pagina='Garagem', aba_ativa='garage', tamanho_lista_meus_carros=1)


@app.route('/cadastro-carros', methods=['GET', 'POST'])
def cadastro_carros():
    return render_template("cadastro-carros.html", pagina='Cadastro de Carros', aba_ativa='cadastro-carros')


@app.route('/inserir-carro', methods=['POST', 'GET'])
def inserir_carro():
    carro = Carro(placa=request.form['placa'].upper(), marca=request.form['marca'].upper(),
                  descricao=request.form['descricao'].upper(),
                  modelo=request.form['modelo'].upper(), cor=request.form['cor'].upper(), valor=request.form['preco'],
                  status=int(request.form.get('listGroupSelectStatus')), imagem=request.form['imagem'])

    db.session.add(carro)
    db.session.commit()

    return redirect(url_for('cadastro_carros'))


@app.route('/perfil/<email>')
def perfil(email):
    cliente = Cliente.query.filter_by(email=email).first()

    return render_template("perfil.html", pagina='Perfil', aba_ativa='perfil',
                           cpf=cliente.cpf, nome=cliente.nome, telefone=cliente.telefone, email=cliente.email,
                           endereco=cliente.endereco, cidade=cliente.cidade, numero=cliente.numero, cep=cliente.cep,
                           bairro=cliente.bairro, data_nascimento=cliente.data_nascimento)


@app.route('/cadastro-cliente')
def cadastro_clientes():
    return render_template("cadastro-cliente.html", pagina='Cadastro de Cliente', aba_ativa='cadastro-clientes')


@app.route('/inserir-cliente', methods=['POST', 'GET'])
def inserir_cliente():
    data = request.form['dataNascimento'].split('-')
    data_nascimento = date(int(data[0]), int(data[1]), int(data[2]))

    cliente = Cliente(cpf=request.form['cpf'], nome=request.form['nomeCompleto'].capitalize(),
                      telefone=request.form['telefone'], email=request.form['email'].lower(),
                      endereco=request.form['endereco'].capitalize(), cidade=request.form['cidade'].capitalize(),
                      numero=request.form['numero'], cep=request.form['cep'],
                      bairro=request.form['bairro'].capitalize(),
                      data_nascimento=data_nascimento, senha=request.form['senha'])

    db.session.add(cliente)
    db.session.commit()

    return redirect(url_for('cadastro_clientes'))


if __name__ == '__main__':
    app.run()
