
class Locacao:

    def __init__(self, db):
        self.id = db.Column(db.Integer, primary_key=True, autoincrement=True)
        self.placa = db.Column(db.String(8), nullable=False)
        self.cpf = db.Column(db.String(11), nullable=False)
        self.data_locacao = db.Column(db.DateTime, nullable=False)
        self.data_devolucao_prevista = db.Column(db.DateTime, nullable=False)
        self.valor = db.Column(db.Float, nullable=False)
        self.data_devolucao = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"Locacao('{self.id}', '{self.placa}', '{self.cpf}', '{self.data_locacao}', " \
               f"'{self.data_devolucao_prevista}', {self.valor}', '{self.data_devolucao}')"
